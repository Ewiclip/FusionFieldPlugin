// Global variable to store stations data
let globalStationsData = null;
let globalActivityData = null;
let activeUserID = "AmerenIDNotMe";

// Method to load and parse XML data from external fake_data.js file
function loadXMLData() {
    return new Promise((resolve, reject) => {
        try {
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(embeddedXMLData, 'text/xml');
            const parsedData = parseXMLData(xmlDoc);
            resolve(parsedData);
        } catch (error) {
            reject('Error parsing XML: ' + error.message);
        }
    });
}

// Method to parse XML data and extract stations information
function parseXMLData(xmlDoc) {
    const activity = xmlDoc.querySelector('activity');
    if (!activity) {
        throw new Error('No activity element found in XML');
    }

    // Parse activity-level data
    const activityData = {
        activityId: getElementText(activity, 'activityId'),
        activityType: getElementText(activity, 'activityType')
    };

    // Parse stations data
    const stations = activity.querySelectorAll('station');
    const stationsData = [];

    stations.forEach(station => {
        const stationData = {
            stationId: getElementText(station, 'stationId'),
            stationName: getElementText(station, 'stationName'),
            location: getElementText(station, 'location'),
            status: getElementText(station, 'status'),
            checkedOutByName: getElementText(station, 'checkedOutByName'),
            checkedOutByID: getElementText(station, 'checkedOutByID'),
            stationCUs: []
        };

        // Parse station CUs
        const stationCUs = station.querySelectorAll('stationCU');
        stationCUs.forEach(cu => {
            const cuData = {
                stockNumber: getElementText(cu, 'stationCUstockNumber'),
                description: getElementText(cu, 'stationCUDescription'),
                cuId: getElementText(cu, 'stationCUId'),
                cuType: getElementText(cu, 'stationCUType'),
                quantityRequired: getElementText(cu, 'stationCUQuantityRequired'),
                quantityInstalled: getElementText(cu, 'stationCUQuantityInstalled'),
                plannedDisposition: getElementText(cu, 'stationCUPlannedDisposition'),
                materialWasNotUsed: getElementText(cu, 'stationCUMaterialWasNotUsed')
            };
            stationData.stationCUs.push(cuData);
        });

        stationsData.push(stationData);
    });

    return {
        activity: activityData,
        stations: stationsData
    };
}

// Helper method to safely get element text
function getElementText(parent, elementName) {
    const element = parent.querySelector(elementName);
    return element ? element.textContent.trim() : '';
}

// Method to display activity information
function displayActivityInfo(activityData) {
    const activityInfoDiv = document.getElementById('activityInfo');
    activityInfoDiv.innerHTML = `
        <h2>Activity Information</h2>
        <p><strong>Activity ID:</strong> ${activityData.activityId}</p>
        <p><strong>Activity Type:</strong> ${activityData.activityType}</p>
    `;
}

// Method to update summary statistics
function updateSummaryStats(stationsData) {
    const totalStations = stationsData.length;
    const totalCUs = getTotalCUs();
    const openStations = getStationsByStatus('Open').length;
    const completeStations = getStationsByStatus('Complete').length;
    const checkedOutStations = getStationsByStatus('Checked Out').length;
    
    document.getElementById('totalStations').textContent = totalStations;
    document.getElementById('totalCUs').textContent = totalCUs;
    document.getElementById('openStations').textContent = openStations;
    document.getElementById('completeStations').textContent = completeStations;
    document.getElementById('checkedOutStations').textContent = checkedOutStations;
}

// Method to display stations
function displayStations(stationsData) {
    const container = document.getElementById('stationsContainer');
    
    if (!stationsData || stationsData.length === 0) {
        container.innerHTML = '<div class="error">No stations data available</div>';
        return;
    }

    // Filter stations based on hide complete checkbox
    const hideComplete = document.getElementById('hideCompleteStations')?.checked || false;
    const filteredStations = hideComplete ? stationsData.filter(station => station.status !== 'Complete' && station.status !== 'Checked Out') : stationsData;

    const stationsHTML = filteredStations.map((station, index) => {
        const statusClass = station.status === 'Complete' ? 'status-complete' : 
                           station.status === 'Checked Out' ? 'status-checked-out' : 'status-open';
        
        // Check if station is checked out and current user doesn't have access
        const isCheckedOutByOther = station.status === 'Checked Out' && station.checkedOutByID !== activeUserID;
        
                 const cusHTML = station.stationCUs.map(cu => {
             const deletedClass = cu.deleted ? 'cu-deleted' : '';
             const isNewRow = cu.isNew;
             
             // Determine input classes based on whether it's a new row and station status
             const stockInputClass = isNewRow && !isCheckedOutByOther ? 'cu-editable-input tooltip-trigger' : 'cu-readonly-input tooltip-trigger';
             const descInputClass = isNewRow && !isCheckedOutByOther ? 'cu-editable-input tooltip-trigger' : 'cu-readonly-input tooltip-trigger';
             const dispSelectClass = isNewRow && !isCheckedOutByOther ? 'cu-editable-select' : 'cu-readonly-select';
             const requiredInputClass = isNewRow ? 'cu-readonly-input' : 'cu-readonly-input';
             const installedInputClass = isNewRow && !isCheckedOutByOther ? 'cu-editable-input' : 'cu-installed-input';
             
                           return `
                  <div class="cu-grid-row ${deletedClass} ${isNewRow ? 'cu-new-row' : ''}">
                      <div class="cu-stock">
                          <div class="stock-input-container">
                              <input type="text" 
                                     class="${stockInputClass}" 
                                     value="${cu.stockNumber}" 
                                     ${isNewRow && station.status !== 'Complete' && !isCheckedOutByOther ? '' : 'readonly'}
                                     onclick="event.stopPropagation()"
                                     title="${cu.stockNumber}"
                                     ${isNewRow && station.status !== 'Complete' && !isCheckedOutByOther ? `onchange="updateCUField('${station.stationId}', '${cu.cuId}', 'stockNumber', this.value)"` : ''}
                              />
                                                                                           ${isNewRow && station.status !== 'Complete' && !isCheckedOutByOther && !cu.deleted ? `<div class="search-icon" onclick="event.stopPropagation(); openSearchModal('${station.stationId}', '${cu.cuId}', 'stockNumber')">
                                    <div class="search-magnifier"></div>
                                </div>` : ''}
                          </div>
                      </div>
                      <div class="cu-description">
                          <input type="text" 
                                 class="${descInputClass}" 
                                 value="${cu.description}" 
                                 ${isNewRow && station.status !== 'Complete' && !isCheckedOutByOther ? '' : 'readonly'}
                                 onclick="event.stopPropagation()"
                                 title="${cu.description}"
                                 ${isNewRow && station.status !== 'Complete' && !isCheckedOutByOther ? `onchange="updateCUField('${station.stationId}', '${cu.cuId}', 'description', this.value)"` : ''}
                          />
                      </div>
                      <div class="cu-disposition">
                          <select class="${dispSelectClass}" 
                                  onclick="event.stopPropagation()"
                                  ${isNewRow && station.status !== 'Complete' && !isCheckedOutByOther ? '' : 'disabled'}
                                                                     ${isNewRow && station.status !== 'Complete' && !isCheckedOutByOther ? `onchange="updateCUField('${station.stationId}', '${cu.cuId}', 'plannedDisposition', this.value)"` : ''}>
                              <option value="Install" ${cu.plannedDisposition === 'Install' ? 'selected' : ''}>Install</option>
                              <option value="Scrap" ${cu.plannedDisposition === 'Scrap' ? 'selected' : ''}>Scrap</option>
                              <option value="Remove" ${cu.plannedDisposition === 'Remove' ? 'selected' : ''}>Remove</option>
                              <option value="Transfer" ${cu.plannedDisposition === 'Transfer' ? 'selected' : ''}>Transfer</option>
                              <option value="Keeper" ${cu.plannedDisposition === 'Keeper' ? 'selected' : ''}>Keeper</option>
                          </select>
                      </div>
                      <div class="cu-required">
                          <div class="required-input-container">
                              <input type="number" 
                                     class="${requiredInputClass}" 
                                     value="${cu.quantityRequired}" 
                                     readonly
                                     onclick="event.stopPropagation()"
                              />
                                                             ${cu.quantityRequired > 0 && !cu.deleted && !isCheckedOutByOther ? `<div class="required-icon" onclick="event.stopPropagation(); copyRequiredToInstalled('${station.stationId}', '${cu.cuId}')">»</div>` : ''}
                          </div>
                      </div>
                      <div class="cu-installed">
                          <input type="number" 
                                 class="${installedInputClass}" 
                                 value="${cu.quantityInstalled}" 
                                 min="0" 
                                 step="1"
                                 ${station.status === 'Complete' || isCheckedOutByOther ? 'readonly' : ''}
                                 onclick="event.stopPropagation()"
                                 ${station.status !== 'Complete' && !isCheckedOutByOther ? `onchange="updateInstalledQuantity('${station.stationId}', '${cu.cuId}', this.value)"` : ''}
                                 ${station.status !== 'Complete' && !isCheckedOutByOther ? 'onkeypress="return event.charCode >= 48 && event.charCode <= 57"' : ''}
                          />
                      </div>
                      <div class="cu-actions">
                          ${station.status !== 'Complete' && !isCheckedOutByOther ? `<div class="trash-icon" onclick="event.stopPropagation(); toggleCUDeleted('${station.stationId}', '${cu.cuId}')">
                              <div class="trash-lid"></div>
                              <div class="trash-body"></div>
                          </div>` : ''}
                      </div>
                  </div>
              `;
         }).join('');

                return `
            <div class="station-card" data-station-id="${station.stationId}">
                <div class="accordion-header" onclick="toggleAccordion('${station.stationId}')">
                    <div class="station-info">
                        <div class="station-id-name">${station.stationId} - ${station.stationName}</div>
                        <div class="station-location-status">
                            <span><strong>Location:</strong> ${station.location}</span>
                            <span class="status-badge ${statusClass}">${station.status}</span>
                        </div>
                    </div>
                    <div class="accordion-icon">▼</div>
                </div>
                                 <div class="accordion-content" id="accordion-${station.stationId}">
                     <div class="accordion-inner ${station.status === 'Complete' ? 'station-complete' : ''} ${isCheckedOutByOther ? 'station-checked-out' : ''}">
                         ${station.status === 'Complete' ? '<div class="complete-overlay"></div>' : ''}
                         ${isCheckedOutByOther ? '<div class="checked-out-overlay"></div>' : ''}
                         <div class="cu-grid">
                                                         <div class="cu-grid-header">
                                 <div class="cu-stock">Stock #</div>
                                 <div class="cu-description">Description</div>
                                 <div class="cu-disposition">Planned Disposition</div>
                                                                   <div class="cu-required">
                                      <div class="planned-qty-container">
                                          <span class="planned-qty-label">Planned Qty</span>
                                          ${station.status !== 'Complete' && !isCheckedOutByOther ? `<div class="copy-all-btn" onclick="event.stopPropagation(); copyAllRequiredToInstalled('${station.stationId}')" title="Copy all planned quantities to actual quantities">Bulk >></div>` : ''}
                                      </div>
                                  </div>
                                 <div class="cu-installed">Actual Qty</div>
                                 <div class="cu-actions">Actions</div>
                             </div>
                                                         ${cusHTML}
                         </div>
                                                                             <div class="button-section">
                             <button class="add-row-btn" onclick="event.stopPropagation(); addNewRow('${station.stationId}')" ${station.status === 'Complete' ? 'disabled' : ''}>
                                 <span class="add-icon">+</span>
                                 Add New Row
                             </button>
                             ${station.status === 'Complete' ? '<div class="complete-message">✓ Station Complete - Read Only</div>' : ''}
                             ${isCheckedOutByOther ? `<div class="checked-out-message">
                                 <div class="checked-out-line1">🔒 Station Checked Out</div>
                                 <div class="checked-out-line2">${station.checkedOutByID} - ${station.checkedOutByName}</div>
                             </div>` : ''}
                             <button class="complete-station-btn" onclick="event.stopPropagation(); completeStation('${station.stationId}')" ${station.status === 'Complete' ? 'disabled' : ''}>
                                 <span class="complete-icon">✓</span>
                                 Complete Station
                             </button>
                         </div>
                   </div>
               </div>
           </div>
       `;
     }).join('');

    container.innerHTML = `<div class="stations-accordion">${stationsHTML}</div>`;
}

// Method to toggle accordion sections
function toggleAccordion(stationId) {
    const stationCard = document.querySelector(`[data-station-id="${stationId}"]`);
    const header = stationCard.querySelector('.accordion-header');
    const content = document.getElementById(`accordion-${stationId}`);
    
    // Check if this accordion is currently active
    const isCurrentlyActive = header.classList.contains('active');
    
    // Close all other accordions first
    const allHeaders = document.querySelectorAll('.accordion-header');
    const allContents = document.querySelectorAll('.accordion-content');
    
    allHeaders.forEach(h => {
        if (h !== header) {
            h.classList.remove('active');
        }
    });
    
    allContents.forEach(c => {
        if (c !== content) {
            c.classList.remove('active');
        }
    });
    
    // Toggle the clicked accordion
    if (!isCurrentlyActive) {
        // Open the clicked accordion
        header.classList.add('active');
        content.classList.add('active');
        
        // Move the expanded accordion to the top
        moveAccordionToTop(stationId);
    } else {
        // Close the clicked accordion (since it was already open)
        header.classList.remove('active');
        content.classList.remove('active');
    }
}

// Method to move an accordion to the top of the list
function moveAccordionToTop(stationId) {
    const accordionContainer = document.querySelector('.stations-accordion');
    const expandedCard = document.querySelector(`[data-station-id="${stationId}"]`);
    
    // Check if it's already at the top
    if (accordionContainer.firstChild === expandedCard) {
        return;
    }
    
    // Remove it from its current position
    expandedCard.remove();
    
    // Insert it at the beginning
    accordionContainer.insertBefore(expandedCard, accordionContainer.firstChild);
    
    // Update the global data order to match the new visual order
    updateGlobalDataOrder(stationId);
}

// Method to update global data order after moving accordion
function updateGlobalDataOrder(stationId) {
    if (!globalStationsData) return;
    
    // Find the expanded station data by stationId
    const expandedStationIndex = globalStationsData.findIndex(station => station.stationId === stationId);
    
    if (expandedStationIndex === -1) return;
    
    // Get the expanded station data
    const expandedStation = globalStationsData[expandedStationIndex];
    
    // Remove it from its current position
    globalStationsData.splice(expandedStationIndex, 1);
    
    // Add it to the beginning
    globalStationsData.unshift(expandedStation);
}

// Method to toggle deleted state of a CU (apply strikethrough)
function toggleCUDeleted(stationId, cuId) {
    if (!globalStationsData) return;
    
    // Find the station
    const station = globalStationsData.find(s => s.stationId === stationId);
    if (!station) return;
    
    // Find the CU
    const cu = station.stationCUs.find(cu => cu.cuId === cuId);
    if (!cu) return;
    
    // Remember which accordion is currently open
    const openAccordion = document.querySelector('.accordion-header.active');
    const openStationId = openAccordion ? openAccordion.closest('[data-station-id]').getAttribute('data-station-id') : null;
    
    // Toggle the deleted state
    cu.deleted = !cu.deleted;
    
    // Refresh the display
    displayStations(globalStationsData);
    
    // Restore the accordion state
    if (openStationId) {
        const headerToReopen = document.querySelector(`[data-station-id="${openStationId}"] .accordion-header`);
        const contentToReopen = document.getElementById(`accordion-${openStationId}`);
        if (headerToReopen && contentToReopen) {
            headerToReopen.classList.add('active');
            contentToReopen.classList.add('active');
        }
    }
    
    console.log(`Toggled deleted state for CU ${cuId} in station ${stationId}: ${cu.deleted}`);
}

// Method to update installed quantity for a CU
function updateInstalledQuantity(stationId, cuId, newValue) {
    if (!globalStationsData) return;
    
    // Find the station
    const station = globalStationsData.find(s => s.stationId === stationId);
    if (!station) return;
    
    // Find the CU
    const cu = station.stationCUs.find(cu => cu.cuId === cuId);
    if (!cu) return;
    
    // Parse and validate the new value
    const quantity = parseInt(newValue, 10);
    if (isNaN(quantity) || quantity < 0) {
        // Reset to previous value if invalid
        const input = document.querySelector(`[data-station-id="${stationId}"] input[onchange*="${cuId}"]`);
        if (input) {
            input.value = cu.quantityInstalled;
        }
        return;
    }
    
    // Update the quantity
    cu.quantityInstalled = quantity;
    
    console.log(`Updated installed quantity for CU ${cuId} in station ${stationId}: ${quantity}`);
}

// Method to add a new row to a station
function addNewRow(stationId) {
    if (!globalStationsData) return;
    
    // Find the station
    const station = globalStationsData.find(s => s.stationId === stationId);
    if (!station) return;
    
    // Generate a unique CU ID for the new row
    const existingCUs = station.stationCUs;
    const maxCuId = Math.max(...existingCUs.map(cu => parseInt(cu.cuId.replace('CU', ''))), 0);
    const newCuId = `CU${String(maxCuId + 1).padStart(3, '0')}`;
    
    // Create new CU data
    const newCu = {
        stockNumber: '',
        description: '',
        cuId: newCuId,
        cuType: '',
        quantityRequired: '0',
        quantityInstalled: '0',
        plannedDisposition: 'Install',
        materialWasNotUsed: 'false',
        isNew: true // Flag to identify this as a new row
    };
    
    // Add to station's CUs
    station.stationCUs.push(newCu);
    
    // Remember which accordion is currently open
    const openAccordion = document.querySelector('.accordion-header.active');
    const openStationId = openAccordion ? openAccordion.closest('[data-station-id]').getAttribute('data-station-id') : null;
    
    // Refresh the display
    displayStations(globalStationsData);
    
    // Restore the accordion state
    if (openStationId) {
        const headerToReopen = document.querySelector(`[data-station-id="${openStationId}"] .accordion-header`);
        const contentToReopen = document.getElementById(`accordion-${openStationId}`);
        if (headerToReopen && contentToReopen) {
            headerToReopen.classList.add('active');
            contentToReopen.classList.add('active');
        }
    }
    
    // Focus on the first input of the new row
    setTimeout(() => {
        const newRow = document.querySelector(`[data-station-id="${stationId}"] .cu-grid-row:last-child .cu-stock input`);
        if (newRow) {
            newRow.focus();
        }
    }, 100);
    
    console.log(`Added new row to station ${stationId} with CU ID: ${newCuId}`);
}

// Method to update CU field values for new rows
function updateCUField(stationId, cuId, fieldName, newValue) {
    if (!globalStationsData) return;
    
    // Find the station
    const station = globalStationsData.find(s => s.stationId === stationId);
    if (!station) return;
    
    // Find the CU
    const cu = station.stationCUs.find(cu => cu.cuId === cuId);
    if (!cu) return;
    
    // Update the field
    cu[fieldName] = newValue;
    
    console.log(`Updated ${fieldName} for CU ${cuId} in station ${stationId}: ${newValue}`);
}

// Method to complete a station
function completeStation(stationId) {
    if (!globalStationsData) return;
    
    // Find the station
    const station = globalStationsData.find(s => s.stationId === stationId);
    if (!station) return;
    
    // Update the station status to Complete
    station.status = 'Complete';
    
    // Remember which accordion is currently open
    const openAccordion = document.querySelector('.accordion-header.active');
    const openStationId = openAccordion ? openAccordion.closest('[data-station-id]').getAttribute('data-station-id') : null;
    
    // Refresh the display to show the updated status
    displayStations(globalStationsData);
    updateSummaryStats(globalStationsData);
    
    // Restore the accordion state
    if (openStationId) {
        const headerToReopen = document.querySelector(`[data-station-id="${openStationId}"] .accordion-header`);
        const contentToReopen = document.getElementById(`accordion-${openStationId}`);
        if (headerToReopen && contentToReopen) {
            headerToReopen.classList.add('active');
            contentToReopen.classList.add('active');
        }
    }
    
    console.log(`Completed station ${stationId}`);
}

// Method to initialize the application
function initializeApp() {
    loadXMLData()
        .then(data => {
            // Store data in global variables
            globalActivityData = data.activity;
            globalStationsData = data.stations;
            
            // Display the data
            displayActivityInfo(globalActivityData);
            updateSummaryStats(globalStationsData);
            displayStations(globalStationsData);
            
            console.log('Data loaded successfully:', data);
        })
        .catch(error => {
            console.error('Error loading data:', error);
            document.getElementById('stationsContainer').innerHTML = 
                `<div class="error">Error loading data: ${error}</div>`;
        });
}

// Method to get stations by status
function getStationsByStatus(status) {
    if (!globalStationsData) return [];
    return globalStationsData.filter(station => station.status === status);
}

// Method to get station by ID
function getStationById(stationId) {
    if (!globalStationsData) return null;
    return globalStationsData.find(station => station.stationId === stationId);
}

// Method to get total number of CUs across all stations
function getTotalCUs() {
    if (!globalStationsData) return 0;
    return globalStationsData.reduce((total, station) => total + station.stationCUs.length, 0);
}

// Search functionality
let currentSearchContext = null;

// Method to open search modal
function openSearchModal(stationId, cuId, fieldName) {
    currentSearchContext = { stationId, cuId, fieldName };
    document.getElementById('searchModal').style.display = 'block';
    document.getElementById('searchStockNumber').value = '';
    document.getElementById('searchDescription').value = '';
    filterSearchResults();
}

// Method to close search modal
function closeSearchModal() {
    document.getElementById('searchModal').style.display = 'none';
    currentSearchContext = null;
}

// Method to filter search results
function filterSearchResults() {
    const stockNumberFilter = document.getElementById('searchStockNumber').value.toLowerCase();
    const descriptionFilter = document.getElementById('searchDescription').value.toLowerCase();
    
    const filteredResults = preValidatedCUData.filter(item => {
        const stockMatch = item.preValidatedCUstockNumber.toLowerCase().includes(stockNumberFilter);
        
        // Handle multiple word search for description
        let descMatch = true;
        if (descriptionFilter.trim()) {
            const searchWords = descriptionFilter.split(' ').filter(word => word.trim() !== '');
            descMatch = searchWords.every(word => 
                item.preValidatedCUDescription.toLowerCase().includes(word)
            );
        }
        
        return stockMatch && descMatch;
    });
    
    displaySearchResults(filteredResults);
}

// Method to display search results
function displaySearchResults(results) {
    const resultsContainer = document.getElementById('searchResultsList');
    
    if (results.length === 0) {
        resultsContainer.innerHTML = '<div class="no-results">No matching materials found.</div>';
        return;
    }
    
    const resultsHTML = results.slice(0, 50).map(item => `
        <div class="search-result-item" onclick="selectSearchResult('${item.preValidatedCUstockNumber}', '${item.preValidatedCUDescription.replace(/'/g, "\\'")}')">
            <div class="search-result-stock">${item.preValidatedCUstockNumber}</div>
            <div class="search-result-description">${item.preValidatedCUDescription}</div>
        </div>
    `).join('');
    
    resultsContainer.innerHTML = resultsHTML;
}

// Method to select a search result
function selectSearchResult(stockNumber, description) {
    if (!currentSearchContext) return;
    
    const { stationId, cuId, fieldName } = currentSearchContext;
    
    // Update the field based on what was being edited
    if (fieldName === 'stockNumber') {
        updateCUField(stationId, cuId, 'stockNumber', stockNumber);
        updateCUField(stationId, cuId, 'description', description);
        
        // Remember which accordion is currently open
        const openAccordion = document.querySelector('.accordion-header.active');
        const openStationId = openAccordion ? openAccordion.closest('[data-station-id]').getAttribute('data-station-id') : null;
        
        // Refresh the display to show the updated values
        displayStations(globalStationsData);
        
        // Restore the accordion state
        if (openStationId) {
            const headerToReopen = document.querySelector(`[data-station-id="${openStationId}"] .accordion-header`);
            const contentToReopen = document.getElementById(`accordion-${openStationId}`);
            if (headerToReopen && contentToReopen) {
                headerToReopen.classList.add('active');
                contentToReopen.classList.add('active');
            }
        }
    }
    
    closeSearchModal();
}

// Method to copy required quantity to installed quantity
function copyRequiredToInstalled(stationId, cuId) {
    if (!globalStationsData) return;
    
    // Find the station
    const station = globalStationsData.find(s => s.stationId === stationId);
    if (!station) return;
    
    // Find the CU
    const cu = station.stationCUs.find(cu => cu.cuId === cuId);
    if (!cu) return;
    
    // Copy the required quantity to installed quantity
    cu.quantityInstalled = cu.quantityRequired;
    
    // Remember which accordion is currently open
    const openAccordion = document.querySelector('.accordion-header.active');
    const openStationId = openAccordion ? openAccordion.closest('[data-station-id]').getAttribute('data-station-id') : null;
    
    // Refresh the display to show the updated value
    displayStations(globalStationsData);
    
    // Restore the accordion state
    if (openStationId) {
        const headerToReopen = document.querySelector(`[data-station-id="${openStationId}"] .accordion-header`);
        const contentToReopen = document.getElementById(`accordion-${openStationId}`);
        if (headerToReopen && contentToReopen) {
            headerToReopen.classList.add('active');
            contentToReopen.classList.add('active');
        }
    }
    
    console.log(`Copied required quantity ${cu.quantityRequired} to installed quantity for CU ${cuId} in station ${stationId}`);
}

// Method to copy all required quantities to installed quantities for a station
function copyAllRequiredToInstalled(stationId) {
    if (!globalStationsData) return;
    
    // Find the station
    const station = globalStationsData.find(s => s.stationId === stationId);
    if (!station) return;
    
    let copiedCount = 0;
    
    // Copy required quantities to installed quantities for all applicable CUs
    station.stationCUs.forEach(cu => {
        // Only copy if required quantity > 0 and CU is not deleted
        if (cu.quantityRequired > 0 && !cu.deleted) {
            cu.quantityInstalled = cu.quantityRequired;
            copiedCount++;
        }
    });
    
    // Remember which accordion is currently open
    const openAccordion = document.querySelector('.accordion-header.active');
    const openStationId = openAccordion ? openAccordion.closest('[data-station-id]').getAttribute('data-station-id') : null;
    
    // Refresh the display to show the updated values
    displayStations(globalStationsData);
    
    // Restore the accordion state
    if (openStationId) {
        const headerToReopen = document.querySelector(`[data-station-id="${openStationId}"] .accordion-header`);
        const contentToReopen = document.getElementById(`accordion-${openStationId}`);
        if (headerToReopen && contentToReopen) {
            headerToReopen.classList.add('active');
            contentToReopen.classList.add('active');
        }
    }
    
    console.log(`Copied required quantities to installed quantities for ${copiedCount} CUs in station ${stationId}`);
}

// Method to toggle complete stations visibility
function toggleCompleteStations() {
    if (globalStationsData) {
        displayStations(globalStationsData);
    }
}

// Close modal when clicking outside of it
window.onclick = function(event) {
    const modal = document.getElementById('searchModal');
    if (event.target === modal) {
        closeSearchModal();
    }
}

// Initialize the application when the page loads
document.addEventListener('DOMContentLoaded', initializeApp);
